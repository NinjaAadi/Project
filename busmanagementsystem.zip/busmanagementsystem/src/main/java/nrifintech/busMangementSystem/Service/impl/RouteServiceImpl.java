package nrifintech.busMangementSystem.Service.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import nrifintech.busMangementSystem.Service.interfaces.RouteService;
import nrifintech.busMangementSystem.entities.Destination;
import nrifintech.busMangementSystem.entities.Route;
import nrifintech.busMangementSystem.entities.RouteMap;
import nrifintech.busMangementSystem.exception.ResouceNotFound;
import nrifintech.busMangementSystem.payloads.ApiResponse;
import nrifintech.busMangementSystem.repositories.DestinationRepo;
import nrifintech.busMangementSystem.repositories.RouteMapRepo;
import nrifintech.busMangementSystem.repositories.RouteRepo;
@Service
public class RouteServiceImpl implements RouteService{

	@Autowired
	private RouteRepo routeRepo;

	@Autowired
	private RouteMapRepo routeMapRepo;
	
	@Override
	@Transactional
	public Route createRoute(List<String> destinations) {
		int start = 0,end = 0;
		for(int i = 0;i<destinations.size();i++) {
			System.out.println(destinations.get(i));
			String dest = destinations.get(i);
			String [] dest_id_time = dest.split("_");
			System.out.println(dest_id_time[1]);
			if(i == 0) {
				start = Integer.parseInt(dest_id_time[0]);
			}
			else if(i == destinations.size()-1) {
				end = Integer.parseInt(dest_id_time[0]);
			}
		}
		Route r = new Route();
		r.setStart_destination_id(start);
		r.setEnd_destination_id(end);
		
		Route createdRoute = routeRepo.save(r);
		for(int i = 0;i<destinations.size();i++) {
			String dest = destinations.get(i);
			String [] dest_id_time = dest.split("_");
			RouteMap rm = new RouteMap();
			rm.setRoute_id(createdRoute.getId());
			rm.setDestination_id(Integer.parseInt(dest_id_time[0]));
			rm.setDestination_index(i);
			rm.setTime(dest_id_time[2]);
			routeMapRepo.save(rm);
		}
		return createdRoute;
	}
	@Override
	public Route updateRoute(Route newRoute, int id) {
		// TODO Auto-generated method stub
		Route  route = routeRepo.findById(id).orElseThrow(() -> new ResouceNotFound("Route", "id", id));
		route.setId(newRoute.getId());
//		route.setDestinations(newRoute.getDestinations());
		
		return this.routeRepo.save(route);
	}

	@Override
	public Route getRoute(int id) {
		// TODO Auto-generated method stub
		 return this.routeRepo.findById(id).orElseThrow(() -> new ResouceNotFound("Route", "id", id));
	}

	@Override
	public List<Route> getRoute() {
		// TODO Auto-generated method stub
		return  this.routeRepo.findAll();
	}

	@Override
	public void deleteRoute(int id) {
		// TODO Auto-generated method stub
		Route route = this.routeRepo.findById(id).orElseThrow(() -> new ResouceNotFound("Route", "id", id));
		routeRepo.delete(route);	
	}
	@Override
	public Route createRoute(Route route) {
		// TODO Auto-generated method stub
		return null;
	}

}
