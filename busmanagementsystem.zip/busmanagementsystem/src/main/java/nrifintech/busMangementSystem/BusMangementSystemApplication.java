package nrifintech.busMangementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusMangementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusMangementSystemApplication.class, args);
	}

}
