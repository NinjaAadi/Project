package nrifintech.busMangementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusMangementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
